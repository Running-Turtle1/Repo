#include<stdio.h>

int main() {
    int a = 10; // ����ע��
    char b = 'c';
    double c=1.4;
//ע��-adsadasdada123131231321
	int i=0;
	for(i=0;i<10;i++)
		printf("asasa10d4ad1.15sd/**/"); 
    printf("2108010316 ����");
	return 0;
}

