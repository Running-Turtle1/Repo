# import toml
import json
# 导入Flask类
from flask import Flask
# 实例化Flask类
app = Flask(__name__)
# 定义视图函数，并为该函数注册路由
@app.route("/")
def hello_flask():
    return "<p>Hello, Flask!</p>"

class Config:
    # 启用测试模式
    TESTING=True
    # 设置密钥
    SECRET_KEY=b'_5#y2L"F4Q8z\n\xec]/'

if __name__ == "__main__":
    # 启动开发服务器
    app.run()

    # 1. 通过访问字典元素的方式使用配置信息
    # app.config['TESTING'] = True
    # app.config.update(
    #     TESTING=True,
    #     SECRET_KEY=b'_5#y2L"F4Q8z\n\xec]/'
    # )

    # 2. 通过导入文件的方式使用配置信息
    # 通过from_file()方法从config.toml文件中导入配置项
    # app.config.from_file("config.toml", load=toml.load)
    # 通过from_json()方法从config.json文件中导入配置项
    # app.config.from_json("config.json")
    # 通过from_pyfile()方法从config.py文件中导入配置项
    # app.config.from_pyfile("config.py")

    # 3. 通过导入对象的方式使用配置信息
    app.config.from_object(Config)