
'''
4.1	通过Flask处理表单
'''
# from flask import Flask, render_template, request, flash
# app = Flask(__name__)
# app.secret_key = 'Your_seccret_key&^52@!'
# @app.route('/register', methods=['GET', 'POST'])
# def register():
#     # 判断请求方式
#     if request.method == 'POST':
#         # 获取表单数据
#         username = request.form.get('username')
#         password = request.form.get('password')
#         password2 = request.form.get('password2')
#         # 验证数据的完整性
#         if not all([username, password, password2]):
#             flash('请填入完整信息', category='message')
#         # 验证输入的数据是否符合要求
#         elif len(username) < 3 and len(username) > 0 or len(username) > 15:
#             flash('用户名长度大于3且小于15', category='info')
#         # 验证两次输入的密码是否一致
#         elif password != password2:
#             flash('密码不一致', category='error')
#         else:
#             return '注册成功'
#     return render_template('register.html')
# if __name__ == '__main__':
#     app.run()


'''
4.2.2	使用Flask-WTF创建表单
'''
# from flask import Flask, render_template
# from flask_wtf import FlaskForm
# from wtforms import StringField, PasswordField, SubmitField
# from wtforms.validators import DataRequired, Length, EqualTo
# app = Flask(__name__)
# class RegisterForm(FlaskForm):
#     username = StringField(label='用户名：',
#                            validators=[DataRequired(message='用户名不能为空'),
#                                        Length(3, 15, message='长度应该为3~15')])
#     password = PasswordField('密码：',
#                              validators=[DataRequired(message='密码不能为空')])
#     password2 = PasswordField('确认密码：',
#                               validators=[DataRequired(message='密码不能为空'),
#                               EqualTo('password', message='两次密码不一致')])
#     submit = SubmitField('注册')


'''
4.2.3	在模板中渲染表单
'''
# app.secret_key = '34sdfji9453#$@'
# @app.route('/register', methods=['GET', 'POST'])
# def register():
#     form = RegisterForm()
#     return render_template('register_wtf.html', form=form)
# if __name__ == '__main__':
#     app.run()


'''
4.2.4	通过Flask-WTF验证表单
'''
# from flask import Flask, render_template
# from flask_wtf import FlaskForm
# from wtforms import StringField, PasswordField, SubmitField
# from wtforms.validators import DataRequired, Length, EqualTo
# class RegisterForm(FlaskForm):
#     username = StringField(label='用户名：', render_kw={'required': False},
#                            validators=[DataRequired(message='用户名不能为空'),
#                                        Length(3, 15, message='长度应该为3~15')])
#     password = PasswordField('密码：', render_kw={'required': False},
#                              validators=[DataRequired(message='密码不能为空')])
#     password2 = PasswordField('确认密码：', render_kw={'required': False},
#                               validators=[DataRequired(message='密码不能为空'),
#                                           EqualTo('password', message='两次密码不一致')])
#     submit = SubmitField('注册')
#
# app = Flask(__name__)
# app.secret_key = '34sdfji9453#$@'
# @app.route('/register', methods=['GET', 'POST'])
# def register():
#     form = RegisterForm()
#     if form.validate_on_submit():
#         return '注册成功！'
#     return render_template('register_wtf.html', form=form)
# if __name__ == '__main__':
#     app.run()


'''
4.3.1	标准类视图
'''
# from flask import Flask, request
# from flask.views import View
#
# # class MyView(View):                             # 定义类视图
# #     def dispatch_request(self, name):        # 重写dispatch_request()方法
# #         return f'hello {name}'
#
# class MyView(View):                              # 定义类视图
#     methods = ['GET', 'POST']                   # 指定请求方式
#     def dispatch_request(self, name):         # 重写dispatch_request()方法
#         if request.method == 'GET':
#             return f'hello {name}'
# app = Flask(__name__)
# # 将类视图与URL规则进行映射
# app.add_url_rule('/hello/<name>', view_func=MyView.as_view('myview'))
# if __name__ == '__main__':
#     app.run()


'''
4.3.2	基于方法的类视图
'''
# from flask.views import MethodView
# from flask import Flask, render_template, request
# class LoginView(MethodView):
#     def get(self):                                       # 处理GET请求
#         return render_template('login.html')
#     def post(self):   							   # 处理POST请求
#         username = request.form.get('username')     # 获取输入的用户名
#         password = request.form.get('password')     # 获取输入的密码
#         # 判断用户名和密码是否为123
#         if username =='flask' and password == '123':
#             return f'用户：{username}登录成功。'
#         else:
#             return '用户名或密码错误，请重新登录。'
# app = Flask(__name__)
# app.add_url_rule('/login', view_func=LoginView.as_view('login'))
# if __name__ == '__main__':
#     app.run()


'''
4.4	蓝图
'''
from admin import admin
from user import user
from flask import Flask
app = Flask(__name__)
app.register_blueprint(admin, url_prefix='/admin')  # 将蓝图admin进行注册
app.register_blueprint(user, url_prefix='/user')    # 将蓝图user进行注册
if __name__ == '__main__':
    app.run()

