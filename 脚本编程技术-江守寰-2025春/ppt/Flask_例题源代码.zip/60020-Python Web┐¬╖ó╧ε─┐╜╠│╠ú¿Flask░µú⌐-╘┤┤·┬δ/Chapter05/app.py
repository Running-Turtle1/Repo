"""
5.3.1 连接数据库
"""
# from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# app = Flask(__name__)
# # 通过URI连接数据库
# app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:1234567@localhost/flask_data'
#
# # 动态追踪数据库的修改，不建议开启
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#
# db = SQLAlchemy(app)

"""
5.4.1 增加数据
"""
# @app.route("/")
# def hello_flask():
#     # 创建User类的对象
#     user1 = User(username="小明", email='123@qq.com')
#     user2 = User(username="小张", email='456@qq.com')
#     user3 = User(username="小红", email='789@qq.com')
#     # 将User类的对象添加到数据库会话中
#     db.session.add(user1)
#     db.session.add_all([user2, user3])
#     # 使用commit()方法从会话提交至数据库
#     db.session.commit()
#     return "OK"
# if __name__ == "__main__":
#     app.run()


"""
5.4.2	查询数据
"""
# # 定义路由及视图函数
# @app.route("/")
# def hello_flask():
#     # 查询全部记录
#     users = User.query.all()
#     print(users)
#     # 查询第一条记录
#     first_user = User.query.first()
#     print(first_user)
#     # 返回主键值2对应的记录
#     id_user = User.query.get(2)
#     print(id_user)
#     # 过滤username等于"小明"的记录
#     users2 = User.query.filter(User.username=="小明").first()
#     print(users2)
#     # 过滤email等于"123@qq.com"的记录
#     users3 = User.query.filter_by(email="123@qq.com").first()
#     print(users3)


"""
5.4.3	更新数据
"""
# @app.route("/")
# def hello_flask():
#     # 返回主键值2对应的记录
#     result = User.query.get(2)
#     print(result.username)
#     # 将username的值修改为"小兰"
#     result.username = "小兰"
#     db.session.commit()
#     return "OK"
# if __name__ == "__main__":
#     app.run()


"""
5.4.4	删除数据
"""
@app.route("/")
def hello_flask():
    # 返回主键值3对应的记录
    result = User.query.get(3)
    print(result)
    db.session.delete(result)
    db.session.commit()
    return "OK"
