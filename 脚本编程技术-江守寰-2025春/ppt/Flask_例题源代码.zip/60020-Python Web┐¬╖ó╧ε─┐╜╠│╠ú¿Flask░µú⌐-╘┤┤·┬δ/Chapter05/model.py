from app import db

# class User(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(80), unique=True, nullable=False)
#     email = db.Column(db.String(120), unique=True, nullable=False)

# 1.一对多关系
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    # 定义关系属性
    article = db.relationship("Article", backref='user', lazy='dynamic')


class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(20), nullable=False)
    # 创建外键
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'))

# 2. 一对一关系
class Country(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    # 定义关系属性，并以标量的形式加载记录
    president = db.relationship("President", back_populates='country',
                                      uselist=False)
class President(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True)
    # 创建外键
    country_id = db.Column(db.Integer, db.ForeignKey('country.id'))
    # 定义关系属性，并以标量的形式加载记录
    president = db.relationship("Country", back_populates='president')

# 3. 多对多关系
# 创建关联表
association_table = db.Table('association',
                             db.Column('student_id', db.Integer, db.ForeignKey('student.id'),
                                       db.Column('teacher_id', db.Integer, db.ForeignKey('teacher.id'),primary_key=True))
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True)
    gender = db.Column(db.String(10), nullable=False)
    teacher = db.relationship('Teacher', secondary=association_table,
                                    back_populates='student')
class Teacher(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=True)
